from django.db import models
from django.contrib.auth.models import User

class Person(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    USERNAME_FIELD='user'
    def __str__(self):
         return self.user

class Work(models.Model):
    owner = models.CharField(max_length=150)
    name = models.CharField(max_length=150)
    total_marks = models.IntegerField()
    path = str(name)+'/question/'
    question = models.FileField(upload_to = path)

    def __str__(self):
        return self.name


class Assignment(models.Model):
    work = models.ForeignKey(Work,on_delete=models.CASCADE)
    name = models.CharField(max_length=150)
    obtained_marks = models.IntegerField()
    path = str(work.name)+'/submissions/'
    submission = models.FileField(upload_to = path)

    def __str__(self):
        return self.name





