from django.shortcuts import render,redirect
from .forms import RegistrationForm,WorkForm,AssignmentForm,updatePass,feedbackForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from .models import Person,Work,Assignment
from django.core.files.storage import FileSystemStorage

def home(request):
    return render(request,'main_home.html')

def register(request):
    if(request.method=='POST'):
        form=RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            form=AuthenticationForm()
            return render(request,'login.html',{'form':form})
        else:
            form=RegistrationForm()
            return render(request,'signup.html',{'form':form})
    else:
        form=RegistrationForm()
        return render(request,'signup.html',{'form':form})

def Login(request):
    if(request.method=='POST'):
        form = AuthenticationForm(request=request, data=request.POST)
        if form.is_valid():
            uname=form.cleaned_data['username']
            upass=form.cleaned_data['password']
            user = authenticate(username=uname, password=upass)
            if user is not None:
                login(request, user)
                if (not(Person.objects.filter(user = request.user).exists())):
                    a = Person(user = request.user)
                    a.save()
                #current = Person.objects.get(user = request.user)
                #works = []
                #for w in Work.objects.all():
                #    if w.owner == current.user.username:
                #        works.append(w)
                #all_works = Work.objects.all()
                return redirect('course_page/')
                #return render(request,'course_page.html',{'all_works':all_works, 'works':works})
                #return render(request,'course_page.html',{'Person':request.user})
        else:
            return redirect('login/')
    else:
        form=AuthenticationForm()
        return render(request,'login.html',{'form':form})


def course(request):
    if request.user.is_authenticated:
        if (not(Person.objects.filter(user = request.user).exists())):
                    a = Person(user = request.user)
                    a.save()
        current = Person.objects.get(user = request.user)
        works = []
        for w in Work.objects.all():
            if w.owner != current.user.username:
                works.append(w)
        #return render(request,'course_page.html')
        return render(request,'course_page.html',{'works':works})
        #return render(request,'course_page.html',{'Person':request.user})
    else:
        return redirect('login/')

def Logout(request):
    if request.user.is_authenticated:
        logout(request)
        return render(request,'main_home.html')
    else :
        return render(request,'main_home.html')

#def create(request): 
 #   n = Work.objects.all().count()
  #  nm = 'Assignment_'+str(int(n+1))
   # tm = 10
    #ass = Work(owner=request.user.username, name=nm, total_marks=tm)
    #ass.save()
    #current = request.user
    #return render(request,'create_work.html',{'Person':current, 'count':n+1})



def create(request): ##### look here
    if (request.method == 'POST'):
        print('yes')
        form = WorkForm(request.POST, request.FILES)
        if form.is_valid():
            wk = form.save(commit=False)
            wk.owner = request.user.username
            wk.save()
            status = True
            return render(request, 'create_work.html',{'work':wk, 'status':status})
        else:
            form = WorkForm()
    else:
        form = WorkForm()
    status = False
    return render(request, 'create_work.html', {'form':form, 'status':status})

 
	#if not request.user.is_authenticated:
	#	return render(request, 'login.html')
	#else:
	#	if request.method == 'POST':
	#		form = CreateForm(data=request.POST)
	#		if form.is_valid():
	#			ass = form.save(commit=False)
	#     		ass.owner = request.user.username
	#			ass.save()
	#			return redirect('login/')
    #
	#	else:
	#		print("###########")
	#		print(request.user)
	#		form = CreateForm()
	#	return render(request, 'create_work.html', {'form': form})

#def create(request):
 #   if (request.method == 'POST'):
  #      form = CreateForm(request.POST)
   #     if form.is_valid():
    #        nm = form.cleaned_data['name']
     #       tm = form.cleaned_data['total_marks']
      #      if (not(Work.objects.filter(name = nm).exists())):
       #             a = Work(owner = request.user.username, name = nm, total_marks = tm)
        #            a.save()
         #   redirect('/course_page/')
    #else:
     #   form = CreateForm()
      #  return render(request,'create_work.html',{'form':form})


def select_work(request):
    if(request.user.is_authenticated):
        current = Person.objects.get(user = request.user)
        works = []
        for w in Work.objects.all():
            if w.owner == current.user.username:
                works.append(w)
        return render(request,'select_work_page.html',{'works':works})
    else:
        form=AuthenticationForm()
        return render(request,'login.html',{'form':form})

def evaluate(request, item):
    if(request.user.is_authenticated):
        current = Person.objects.get(user = request.user)
        work_obj = Work.objects.get(name = item)
        assignments = []
        for a in Assignment.objects.all():
            if a.work == work_obj:
                assignments.append(a)
        return render(request,'evaluate.html',{'assignments':assignments, 'name':item})
    else:
        form=AuthenticationForm()
        return render(request,'login.html',{'form':form})
    

def update(request,*args,**kwargs):
    if(request.user.is_authenticated):
        if(request.method=='POST'):
            form=updatePass(request.POST)
            if form.is_valid():
                user=authenticate(username=request.user.username,password=form.cleaned_data['old_password'])
                if user is not None:
                   user.set_password(form.cleaned_data['password'])
                   user.save()
            return redirect('/course_page/')
        else:
            form=updatePass()
            return render(request,'update.html',{'current':request.user, 'form':form})
    else:
        form=AuthenticationForm()
        return render(request,'login.html',{'form':form})



def submit(request, item):
    if (request.method == 'POST'):
        print('yes')
        form = AssignmentForm(request.POST, request.FILES)
        if form.is_valid():
            ass = form.save(commit=False)
            for w in Work.objects.all():
                if w.name == item:
                    ass.name = request.user.username
                    ass.work = w
                    ass.obtained_marks = -1
                    ass.save()
                    status = False
                    return render(request, 'show.html',{'assign':ass, 'status':status})
        else:
            form = AssignmentForm()
    else:
        current = Person.objects.get(user = request.user)
        work_obj = Work.objects.get(name = item)
        for a in Assignment.objects.all():
            if (a.work == work_obj and a.name == request.user.username):
                status = True
                if(a.obtained_marks == -1):
                    status = False
                return render(request, 'show.html',{'assign':a, 'status':status})
        form = AssignmentForm()
    return render(request, 'submit.html', {'form':form, 'work':work_obj})

def feedback(request, item, instance):
    if (request.method == 'POST'):
        print('yes')
        form = feedbackForm(request.POST)
        if form.is_valid():
            work_obj = Work.objects.get(name = item)
            for a in Assignment.objects.all():
                if (a.work == work_obj and a.name == instance):
                    a.obtained_marks = form.cleaned_data['Marks_Obtained']
                    a.save()
                    status = True
                    return render(request, 'give_feedback.html',{'assign':a, 'status':status})
        else:
            form = feedbackForm()
            status = False
            return render(request, 'give_feedback.html',{'assign':a, 'status':status, 'form':form})
    else:
        current = Person.objects.get(user = request.user)
        work_obj = Work.objects.get(name = item)
        for a in Assignment.objects.all():
            if (a.work == work_obj and a.name == instance):
                status = True
                if(a.obtained_marks == -1):
                    status = False
                    form = feedbackForm()
                    return render(request, 'give_feedback.html',{'assign':a, 'form':form, 'status':status})
                return render(request, 'give_feedback.html',{'assign':a, 'status':status})
