from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django.core import validators
from django.forms import fields
from .models import Work,Assignment,Person

class RegistrationForm(UserCreationForm):
    first_name = forms.CharField(max_length=100, required=True, help_text='Required', widget=forms.TextInput())
    email = forms.CharField(max_length=100, required=True, help_text='Required', widget=forms.TextInput())
    last_name = forms.CharField(max_length=100, required=False, help_text='Optional', widget=forms.TextInput())
    class Meta:
        model=User
        fields=['username','password1','password2','email','first_name','last_name']

#class WorkForm(forms.Form):
 #   owner = forms.CharField(max_length=100, required=True, help_text='Required', widget=forms.TextInput())
  #  name = forms.CharField(max_length=100, required=True, help_text='Required', widget=forms.TextInput())
   # total_marks = forms.IntegerField(required=True, help_text='Required', widget=forms.TextInput())


class WorkForm(forms.ModelForm):
    class Meta:
        model = Work
        fields = ('name', 'total_marks', 'question')


class AssignmentForm(forms.ModelForm):
    class Meta:
        model = Assignment
        fields = ('submission',)

class updatePass(forms.Form):
    old_password=forms.CharField(max_length=100, required=True, help_text='Required', widget=forms.TextInput)
    password=forms.CharField(max_length=100, required=True, help_text='Required', widget=forms.TextInput)

class feedbackForm(forms.Form):
    Marks_Obtained = forms.IntegerField(max_value=10,min_value=0,required=True,help_text='Required',widget=forms.TextInput)            




            
