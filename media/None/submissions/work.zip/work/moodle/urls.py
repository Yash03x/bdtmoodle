"""moodle URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.views.generic import RedirectView
from portal import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name ='home'),
    path('signup/',views.register,name='signup'),
    path('login/',views.Login,name='login'),
    path('logout/',views.Logout,name='logout'),
    path('update/',views.update,name='pass_update'),
    path('update/course_page/',RedirectView.as_view(url='/course_page/')),
    path('signup/signup/', RedirectView.as_view(url='/signup/')),
    path('signup/login/', RedirectView.as_view(url='/login/')),
    path('login/login/', RedirectView.as_view(url='/login/')),
    path('login/signup/', RedirectView.as_view(url='/signup/')),
    path('logout/login/',RedirectView.as_view(url='/login/')),
    path('course_page/logout/',RedirectView.as_view(url='/logout/')),
    path('create_work/logout/',RedirectView.as_view(url='/logout/')),
    path('logout/signup/',RedirectView.as_view(url='/signup/')),
    path('create_work/',views.create,name='create_work'),
    path('login/create_work/course_page/',RedirectView.as_view(url='/course_page/')),
    path('course_page/',views.course,name='course_page'),
    path('login/course_page/',RedirectView.as_view(url='/course_page/')), 
    path('create_work/course_page/',RedirectView.as_view(url='/course_page/')),
    path('course_page/create_work/',RedirectView.as_view(url='/create_work/')),
    path('evaluate_work/',views.select_work,name='evaluate_work'),
    path('evaluate_work/logout/',RedirectView.as_view(url='/logout/')),
    path('login/evaluate_work/course_page/',RedirectView.as_view(url='/course_page/')),
    path('evaluate_work/course_page/',RedirectView.as_view(url='/course_page/')),
    path('course_page/evaluate_work/',RedirectView.as_view(url='/evaluate_work/')),
    path('evaluate_work/<str:item>/<str:instance>/',views.feedback, name='feedback'),   
    path('evaluate_work/<str:item>/',views.evaluate, name='evaluation'),
    path('course_page/<str:item>/',views.submit, name='submission'),
    
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

